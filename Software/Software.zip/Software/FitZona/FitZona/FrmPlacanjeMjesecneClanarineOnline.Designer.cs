﻿
namespace FitZona
{
    partial class FrmPlacanjeMjesecneClanarineOnline
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonNaplati = new System.Windows.Forms.Button();
            this.labelPostanskiBroj = new System.Windows.Forms.Label();
            this.textBoxPostanskiBroj = new System.Windows.Forms.TextBox();
            this.labelZupanija = new System.Windows.Forms.Label();
            this.textBoxZupanija = new System.Windows.Forms.TextBox();
            this.labelGrad = new System.Windows.Forms.Label();
            this.textBoxGrad = new System.Windows.Forms.TextBox();
            this.labelAdresaZaNaplatu = new System.Windows.Forms.Label();
            this.textBoxAdresaZaNaplatu = new System.Windows.Forms.TextBox();
            this.textBoxCVC = new System.Windows.Forms.TextBox();
            this.labelCVC = new System.Windows.Forms.Label();
            this.textBoxDatumIsteka = new System.Windows.Forms.TextBox();
            this.labelDatumIsteka = new System.Windows.Forms.Label();
            this.textBoxKartica = new System.Windows.Forms.TextBox();
            this.labelKartica = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonNaplati
            // 
            this.buttonNaplati.Location = new System.Drawing.Point(160, 288);
            this.buttonNaplati.Name = "buttonNaplati";
            this.buttonNaplati.Size = new System.Drawing.Size(75, 23);
            this.buttonNaplati.TabIndex = 35;
            this.buttonNaplati.Text = "Naplati";
            this.buttonNaplati.UseVisualStyleBackColor = true;
            this.buttonNaplati.Click += new System.EventHandler(this.buttonNaplati_Click);
            // 
            // labelPostanskiBroj
            // 
            this.labelPostanskiBroj.AutoSize = true;
            this.labelPostanskiBroj.Location = new System.Drawing.Point(12, 246);
            this.labelPostanskiBroj.Name = "labelPostanskiBroj";
            this.labelPostanskiBroj.Size = new System.Drawing.Size(76, 13);
            this.labelPostanskiBroj.TabIndex = 34;
            this.labelPostanskiBroj.Text = "Postanski broj:";
            // 
            // textBoxPostanskiBroj
            // 
            this.textBoxPostanskiBroj.Location = new System.Drawing.Point(12, 262);
            this.textBoxPostanskiBroj.Name = "textBoxPostanskiBroj";
            this.textBoxPostanskiBroj.Size = new System.Drawing.Size(223, 20);
            this.textBoxPostanskiBroj.TabIndex = 33;
            // 
            // labelZupanija
            // 
            this.labelZupanija.AutoSize = true;
            this.labelZupanija.Location = new System.Drawing.Point(12, 205);
            this.labelZupanija.Name = "labelZupanija";
            this.labelZupanija.Size = new System.Drawing.Size(51, 13);
            this.labelZupanija.TabIndex = 32;
            this.labelZupanija.Text = "Zupanija:";
            // 
            // textBoxZupanija
            // 
            this.textBoxZupanija.Location = new System.Drawing.Point(12, 221);
            this.textBoxZupanija.Name = "textBoxZupanija";
            this.textBoxZupanija.Size = new System.Drawing.Size(223, 20);
            this.textBoxZupanija.TabIndex = 31;
            // 
            // labelGrad
            // 
            this.labelGrad.AutoSize = true;
            this.labelGrad.Location = new System.Drawing.Point(12, 166);
            this.labelGrad.Name = "labelGrad";
            this.labelGrad.Size = new System.Drawing.Size(33, 13);
            this.labelGrad.TabIndex = 30;
            this.labelGrad.Text = "Grad:";
            // 
            // textBoxGrad
            // 
            this.textBoxGrad.Location = new System.Drawing.Point(12, 182);
            this.textBoxGrad.Name = "textBoxGrad";
            this.textBoxGrad.Size = new System.Drawing.Size(223, 20);
            this.textBoxGrad.TabIndex = 29;
            // 
            // labelAdresaZaNaplatu
            // 
            this.labelAdresaZaNaplatu.AutoSize = true;
            this.labelAdresaZaNaplatu.Location = new System.Drawing.Point(12, 128);
            this.labelAdresaZaNaplatu.Name = "labelAdresaZaNaplatu";
            this.labelAdresaZaNaplatu.Size = new System.Drawing.Size(95, 13);
            this.labelAdresaZaNaplatu.TabIndex = 28;
            this.labelAdresaZaNaplatu.Text = "Adresa za naplatu:";
            // 
            // textBoxAdresaZaNaplatu
            // 
            this.textBoxAdresaZaNaplatu.Location = new System.Drawing.Point(12, 144);
            this.textBoxAdresaZaNaplatu.Name = "textBoxAdresaZaNaplatu";
            this.textBoxAdresaZaNaplatu.Size = new System.Drawing.Size(223, 20);
            this.textBoxAdresaZaNaplatu.TabIndex = 27;
            // 
            // textBoxCVC
            // 
            this.textBoxCVC.Location = new System.Drawing.Point(163, 102);
            this.textBoxCVC.Name = "textBoxCVC";
            this.textBoxCVC.Size = new System.Drawing.Size(72, 20);
            this.textBoxCVC.TabIndex = 26;
            // 
            // labelCVC
            // 
            this.labelCVC.AutoSize = true;
            this.labelCVC.Location = new System.Drawing.Point(163, 86);
            this.labelCVC.Name = "labelCVC";
            this.labelCVC.Size = new System.Drawing.Size(31, 13);
            this.labelCVC.TabIndex = 25;
            this.labelCVC.Text = "CVC:";
            // 
            // textBoxDatumIsteka
            // 
            this.textBoxDatumIsteka.Location = new System.Drawing.Point(12, 102);
            this.textBoxDatumIsteka.Name = "textBoxDatumIsteka";
            this.textBoxDatumIsteka.Size = new System.Drawing.Size(72, 20);
            this.textBoxDatumIsteka.TabIndex = 24;
            // 
            // labelDatumIsteka
            // 
            this.labelDatumIsteka.AutoSize = true;
            this.labelDatumIsteka.Location = new System.Drawing.Point(12, 86);
            this.labelDatumIsteka.Name = "labelDatumIsteka";
            this.labelDatumIsteka.Size = new System.Drawing.Size(72, 13);
            this.labelDatumIsteka.TabIndex = 23;
            this.labelDatumIsteka.Text = "Datum isteka:";
            // 
            // textBoxKartica
            // 
            this.textBoxKartica.Location = new System.Drawing.Point(12, 62);
            this.textBoxKartica.Name = "textBoxKartica";
            this.textBoxKartica.Size = new System.Drawing.Size(223, 20);
            this.textBoxKartica.TabIndex = 22;
            // 
            // labelKartica
            // 
            this.labelKartica.AutoSize = true;
            this.labelKartica.Location = new System.Drawing.Point(12, 46);
            this.labelKartica.Name = "labelKartica";
            this.labelKartica.Size = new System.Drawing.Size(63, 13);
            this.labelKartica.TabIndex = 21;
            this.labelKartica.Text = "Broj kartice:";
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(12, 23);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(223, 20);
            this.textBoxEmail.TabIndex = 20;
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(12, 7);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(35, 13);
            this.labelEmail.TabIndex = 19;
            this.labelEmail.Text = "Email:";
            // 
            // FrmPlacanjeMjesecneClanarineOnline
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(247, 314);
            this.Controls.Add(this.buttonNaplati);
            this.Controls.Add(this.labelPostanskiBroj);
            this.Controls.Add(this.textBoxPostanskiBroj);
            this.Controls.Add(this.labelZupanija);
            this.Controls.Add(this.textBoxZupanija);
            this.Controls.Add(this.labelGrad);
            this.Controls.Add(this.textBoxGrad);
            this.Controls.Add(this.labelAdresaZaNaplatu);
            this.Controls.Add(this.textBoxAdresaZaNaplatu);
            this.Controls.Add(this.textBoxCVC);
            this.Controls.Add(this.labelCVC);
            this.Controls.Add(this.textBoxDatumIsteka);
            this.Controls.Add(this.labelDatumIsteka);
            this.Controls.Add(this.textBoxKartica);
            this.Controls.Add(this.labelKartica);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.labelEmail);
            this.Name = "FrmPlacanjeMjesecneClanarineOnline";
            this.Text = "FrmPlacanjeMjesecneClanarineOnline";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonNaplati;
        private System.Windows.Forms.Label labelPostanskiBroj;
        private System.Windows.Forms.TextBox textBoxPostanskiBroj;
        private System.Windows.Forms.Label labelZupanija;
        private System.Windows.Forms.TextBox textBoxZupanija;
        private System.Windows.Forms.Label labelGrad;
        private System.Windows.Forms.TextBox textBoxGrad;
        private System.Windows.Forms.Label labelAdresaZaNaplatu;
        private System.Windows.Forms.TextBox textBoxAdresaZaNaplatu;
        private System.Windows.Forms.TextBox textBoxCVC;
        private System.Windows.Forms.Label labelCVC;
        private System.Windows.Forms.TextBox textBoxDatumIsteka;
        private System.Windows.Forms.Label labelDatumIsteka;
        private System.Windows.Forms.TextBox textBoxKartica;
        private System.Windows.Forms.Label labelKartica;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Label labelEmail;
    }
}