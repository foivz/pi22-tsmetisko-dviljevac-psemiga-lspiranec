﻿
namespace FitZona
{
    partial class FrmPlacanjeOnlineRezervacija
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelEmail = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxKartica = new System.Windows.Forms.TextBox();
            this.labelKartica = new System.Windows.Forms.Label();
            this.textBoxDatumIsteka = new System.Windows.Forms.TextBox();
            this.labelDatumIsteka = new System.Windows.Forms.Label();
            this.textBoxCVC = new System.Windows.Forms.TextBox();
            this.labelCVC = new System.Windows.Forms.Label();
            this.textBoxAdresaZaNaplatu = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.labelAdresaZaNaplatu = new System.Windows.Forms.Label();
            this.labelGrad = new System.Windows.Forms.Label();
            this.textBoxGrad = new System.Windows.Forms.TextBox();
            this.labelZupanija = new System.Windows.Forms.Label();
            this.textBoxZupanija = new System.Windows.Forms.TextBox();
            this.labelPostanskiBroj = new System.Windows.Forms.Label();
            this.textBoxPostanskiBroj = new System.Windows.Forms.TextBox();
            this.buttonNaplati = new System.Windows.Forms.Button();
            this.labelPopust = new System.Windows.Forms.Label();
            this.labelIznosPopusta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(12, 9);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(35, 13);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 1;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(12, 25);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(223, 20);
            this.textBoxEmail.TabIndex = 2;
            // 
            // textBoxKartica
            // 
            this.textBoxKartica.Location = new System.Drawing.Point(12, 64);
            this.textBoxKartica.Name = "textBoxKartica";
            this.textBoxKartica.Size = new System.Drawing.Size(223, 20);
            this.textBoxKartica.TabIndex = 4;
            // 
            // labelKartica
            // 
            this.labelKartica.AutoSize = true;
            this.labelKartica.Location = new System.Drawing.Point(12, 48);
            this.labelKartica.Name = "labelKartica";
            this.labelKartica.Size = new System.Drawing.Size(63, 13);
            this.labelKartica.TabIndex = 3;
            this.labelKartica.Text = "Broj kartice:";
            // 
            // textBoxDatumIsteka
            // 
            this.textBoxDatumIsteka.Location = new System.Drawing.Point(12, 104);
            this.textBoxDatumIsteka.Name = "textBoxDatumIsteka";
            this.textBoxDatumIsteka.Size = new System.Drawing.Size(72, 20);
            this.textBoxDatumIsteka.TabIndex = 6;
            // 
            // labelDatumIsteka
            // 
            this.labelDatumIsteka.AutoSize = true;
            this.labelDatumIsteka.Location = new System.Drawing.Point(12, 88);
            this.labelDatumIsteka.Name = "labelDatumIsteka";
            this.labelDatumIsteka.Size = new System.Drawing.Size(72, 13);
            this.labelDatumIsteka.TabIndex = 5;
            this.labelDatumIsteka.Text = "Datum isteka:";
            // 
            // textBoxCVC
            // 
            this.textBoxCVC.Location = new System.Drawing.Point(163, 104);
            this.textBoxCVC.Name = "textBoxCVC";
            this.textBoxCVC.Size = new System.Drawing.Size(72, 20);
            this.textBoxCVC.TabIndex = 8;
            // 
            // labelCVC
            // 
            this.labelCVC.AutoSize = true;
            this.labelCVC.Location = new System.Drawing.Point(163, 88);
            this.labelCVC.Name = "labelCVC";
            this.labelCVC.Size = new System.Drawing.Size(31, 13);
            this.labelCVC.TabIndex = 7;
            this.labelCVC.Text = "CVC:";
            // 
            // textBoxAdresaZaNaplatu
            // 
            this.textBoxAdresaZaNaplatu.Location = new System.Drawing.Point(12, 146);
            this.textBoxAdresaZaNaplatu.Name = "textBoxAdresaZaNaplatu";
            this.textBoxAdresaZaNaplatu.Size = new System.Drawing.Size(223, 20);
            this.textBoxAdresaZaNaplatu.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 9;
            // 
            // labelAdresaZaNaplatu
            // 
            this.labelAdresaZaNaplatu.AutoSize = true;
            this.labelAdresaZaNaplatu.Location = new System.Drawing.Point(12, 130);
            this.labelAdresaZaNaplatu.Name = "labelAdresaZaNaplatu";
            this.labelAdresaZaNaplatu.Size = new System.Drawing.Size(95, 13);
            this.labelAdresaZaNaplatu.TabIndex = 11;
            this.labelAdresaZaNaplatu.Text = "Adresa za naplatu:";
            // 
            // labelGrad
            // 
            this.labelGrad.AutoSize = true;
            this.labelGrad.Location = new System.Drawing.Point(12, 168);
            this.labelGrad.Name = "labelGrad";
            this.labelGrad.Size = new System.Drawing.Size(33, 13);
            this.labelGrad.TabIndex = 13;
            this.labelGrad.Text = "Grad:";
            // 
            // textBoxGrad
            // 
            this.textBoxGrad.Location = new System.Drawing.Point(12, 184);
            this.textBoxGrad.Name = "textBoxGrad";
            this.textBoxGrad.Size = new System.Drawing.Size(223, 20);
            this.textBoxGrad.TabIndex = 12;
            // 
            // labelZupanija
            // 
            this.labelZupanija.AutoSize = true;
            this.labelZupanija.Location = new System.Drawing.Point(12, 207);
            this.labelZupanija.Name = "labelZupanija";
            this.labelZupanija.Size = new System.Drawing.Size(51, 13);
            this.labelZupanija.TabIndex = 15;
            this.labelZupanija.Text = "Zupanija:";
            // 
            // textBoxZupanija
            // 
            this.textBoxZupanija.Location = new System.Drawing.Point(12, 223);
            this.textBoxZupanija.Name = "textBoxZupanija";
            this.textBoxZupanija.Size = new System.Drawing.Size(223, 20);
            this.textBoxZupanija.TabIndex = 14;
            // 
            // labelPostanskiBroj
            // 
            this.labelPostanskiBroj.AutoSize = true;
            this.labelPostanskiBroj.Location = new System.Drawing.Point(12, 248);
            this.labelPostanskiBroj.Name = "labelPostanskiBroj";
            this.labelPostanskiBroj.Size = new System.Drawing.Size(76, 13);
            this.labelPostanskiBroj.TabIndex = 17;
            this.labelPostanskiBroj.Text = "Postanski broj:";
            // 
            // textBoxPostanskiBroj
            // 
            this.textBoxPostanskiBroj.Location = new System.Drawing.Point(12, 264);
            this.textBoxPostanskiBroj.Name = "textBoxPostanskiBroj";
            this.textBoxPostanskiBroj.Size = new System.Drawing.Size(223, 20);
            this.textBoxPostanskiBroj.TabIndex = 16;
            // 
            // buttonNaplati
            // 
            this.buttonNaplati.Location = new System.Drawing.Point(160, 315);
            this.buttonNaplati.Name = "buttonNaplati";
            this.buttonNaplati.Size = new System.Drawing.Size(75, 23);
            this.buttonNaplati.TabIndex = 18;
            this.buttonNaplati.Text = "Naplati";
            this.buttonNaplati.UseVisualStyleBackColor = true;
            this.buttonNaplati.Click += new System.EventHandler(this.buttonNaplati_Click);
            // 
            // labelPopust
            // 
            this.labelPopust.AutoSize = true;
            this.labelPopust.Location = new System.Drawing.Point(9, 287);
            this.labelPopust.Name = "labelPopust";
            this.labelPopust.Size = new System.Drawing.Size(43, 13);
            this.labelPopust.TabIndex = 19;
            this.labelPopust.Text = "Popust:";
            // 
            // labelIznosPopusta
            // 
            this.labelIznosPopusta.AutoSize = true;
            this.labelIznosPopusta.Location = new System.Drawing.Point(58, 287);
            this.labelIznosPopusta.Name = "labelIznosPopusta";
            this.labelIznosPopusta.Size = new System.Drawing.Size(21, 13);
            this.labelIznosPopusta.TabIndex = 20;
            this.labelIznosPopusta.Text = "0%";
            // 
            // FrmPlacanjeOnline
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(243, 392);
            this.Controls.Add(this.labelIznosPopusta);
            this.Controls.Add(this.labelPopust);
            this.Controls.Add(this.buttonNaplati);
            this.Controls.Add(this.labelPostanskiBroj);
            this.Controls.Add(this.textBoxPostanskiBroj);
            this.Controls.Add(this.labelZupanija);
            this.Controls.Add(this.textBoxZupanija);
            this.Controls.Add(this.labelGrad);
            this.Controls.Add(this.textBoxGrad);
            this.Controls.Add(this.labelAdresaZaNaplatu);
            this.Controls.Add(this.textBoxAdresaZaNaplatu);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxCVC);
            this.Controls.Add(this.labelCVC);
            this.Controls.Add(this.textBoxDatumIsteka);
            this.Controls.Add(this.labelDatumIsteka);
            this.Controls.Add(this.textBoxKartica);
            this.Controls.Add(this.labelKartica);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelEmail);
            this.Name = "FrmPlacanjeOnline";
            this.Text = "FrmPlacanjeOnline";
            this.Load += new System.EventHandler(this.FrmPlacanjeOnline_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxKartica;
        private System.Windows.Forms.Label labelKartica;
        private System.Windows.Forms.TextBox textBoxDatumIsteka;
        private System.Windows.Forms.Label labelDatumIsteka;
        private System.Windows.Forms.TextBox textBoxCVC;
        private System.Windows.Forms.Label labelCVC;
        private System.Windows.Forms.TextBox textBoxAdresaZaNaplatu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelAdresaZaNaplatu;
        private System.Windows.Forms.Label labelGrad;
        private System.Windows.Forms.TextBox textBoxGrad;
        private System.Windows.Forms.Label labelZupanija;
        private System.Windows.Forms.TextBox textBoxZupanija;
        private System.Windows.Forms.Label labelPostanskiBroj;
        private System.Windows.Forms.TextBox textBoxPostanskiBroj;
        private System.Windows.Forms.Button buttonNaplati;
        private System.Windows.Forms.Label labelPopust;
        private System.Windows.Forms.Label labelIznosPopusta;
    }
}